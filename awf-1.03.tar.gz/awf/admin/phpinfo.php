<?
/*
        Copyright (C) 2000-2002 Liquid Bytes (R), Germany. All rights reserved.
	http://www.liquidbytes.net/
 
        This file is part of the liquidbytes.net Adaptive Website Framework (AWF)
        The author is Michael Mayer (michael@liquidbytes.net)
        Last update: 08.01.2002
*/

?>

<html>
<head>
<title>
Liquid Bytes AWF PHP Info
</title>
<?
        include('header.inc');
	phpinfo();
	include('footer.inc');
?>
</body>
</html>
