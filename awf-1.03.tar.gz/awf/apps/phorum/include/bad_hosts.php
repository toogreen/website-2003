<?php
  // to use this file add a line like this:
  // $hosts[]="the.bad.host.name.com";
  // regexp can be used to disallow entire networks:

  // $hosts[]="^555.555.555";
  // would disallow anyone with an IP that starts with 555.555.555.

  // $hosts[]="555.555.555$";
  // would disallow anyone with an IP that ends with 555.555.555.

  // $hosts[]="555.555.555";
  // would disallow anyone with an IP that contains 555.555.555.

  // $hosts[]="";

?>